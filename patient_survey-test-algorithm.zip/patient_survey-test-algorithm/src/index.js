import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App'; // 확장자 .js 제거
import reportWebVitals from './reportWebVitals'; // 확장자 .js 제거
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme'; // 확장자 .js 제거

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <App />
    </ThemeProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
